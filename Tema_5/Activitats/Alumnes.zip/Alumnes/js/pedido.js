 let pedido =[
    {
    nombreArticulo : "Maillot Invitus Pro",
    precioArticulo : 49,
    tallas : ["XS","S","M","L","XL","XXL","XXXL"],
    imagen : "maillot.jpg"
    },
    {
    nombreArticulo : "Culote",
    precioArticulo : 57,
    tallas : ["XS","S","M","L","XL","XXL","XXXL"],
    imagen : "culot.jpg"
    },
    {
    nombreArticulo : "Chaleco",
    precioArticulo : 32,
    tallas : ["XS","S","M","L","XL","XXL","XXXL"],
    imagen : "chaleco.jpg"
    },
    {
    nombreArticulo : "Manguitos",
    precioArticulo : 16,
    tallas : ["14 años","S-M","L-XL"],
    imagen : "manguitos.jpg"
    },
    {
        nombreArticulo : "Calcetines",
        precioArticulo : 6,
        tallas : ["XS-S","M-L","XL"],
        imagen : "calcetines.jpg"
        }
];

